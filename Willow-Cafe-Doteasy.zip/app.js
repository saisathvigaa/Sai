const header = document.querySelector('.site-header');
const toggle = document.querySelector('.menu-toggle');
const mobileNav = document.querySelector('#mobile-nav');
function closeMenu() { toggle.setAttribute('aria-expanded','false'); toggle.setAttribute('aria-label','Open navigation'); mobileNav.hidden = true; }
toggle.addEventListener('click', () => { const opening = toggle.getAttribute('aria-expanded') !== 'true'; toggle.setAttribute('aria-expanded', String(opening)); toggle.setAttribute('aria-label', opening ? 'Close navigation' : 'Open navigation'); mobileNav.hidden = !opening; });
mobileNav.querySelectorAll('a').forEach(link => link.addEventListener('click',closeMenu));
document.addEventListener('keydown', event => { if(event.key === 'Escape' && !mobileNav.hidden) {closeMenu();toggle.focus();} });
document.addEventListener('click', event => { if(!header.contains(event.target)) closeMenu(); });
window.addEventListener('resize', () => { if(window.innerWidth > 850) closeMenu(); }, {passive:true});
function updateHeader() { header.classList.toggle('scrolled', window.scrollY > 35); }
updateHeader(); window.addEventListener('scroll',updateHeader,{passive:true});

if('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver(entries => { entries.forEach(entry => { if(entry.isIntersecting) {entry.target.classList.remove('pending-reveal');observer.unobserve(entry.target);} }); }, {threshold:.08,rootMargin:'0px 0px 25px 0px'});
  document.querySelectorAll('.reveal').forEach(el => { if(el.getBoundingClientRect().top > window.innerHeight) {el.classList.add('pending-reveal');observer.observe(el);} });
}
if('IntersectionObserver' in window) {
  const links = [...document.querySelectorAll('.desktop-nav a')];
  const active = new IntersectionObserver(entries => { entries.forEach(entry => {if(entry.isIntersecting) {links.forEach(link => link.classList.toggle('active',link.hash === '#' + entry.target.id));} }); }, {rootMargin:'-15% 0px -55% 0px', threshold:0});
  document.querySelectorAll('#menu,#story,#moments,#visit').forEach(section => active.observe(section));
}

const privacyDialog=document.querySelector('#privacy-dialog');
const privacyTrigger=document.querySelector('.privacy-trigger');
privacyTrigger.addEventListener('click',()=>{privacyDialog.showModal();document.body.classList.add('dialog-open');});
document.querySelectorAll('.dialog-close,.dialog-done').forEach(button=>button.addEventListener('click',()=>privacyDialog.close()));
privacyDialog.addEventListener('close',()=>{document.body.classList.remove('dialog-open');privacyTrigger.focus();});
privacyDialog.addEventListener('click',event=>{if(event.target === privacyDialog){const rect=privacyDialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom) privacyDialog.close();}});

const carousel = document.querySelector('.moments-carousel');
const track = carousel.querySelector('.moments-track');
const slides = [...track.querySelectorAll('.moment-slide')];
const previous = carousel.querySelector('.carousel-prev');
const next = carousel.querySelector('.carousel-next');
const play = carousel.querySelector('.carousel-play');
const count = carousel.querySelector('.carousel-count');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let playing = !reducedMotion.matches;
let inView = false;
let hovered = false;
let focused = false;
let timer;
let direction = 1;
carousel.querySelector('.carousel-controls').hidden = false;

function positions() {
  const start = slides[0].offsetLeft;
  const max = track.scrollWidth - track.clientWidth;
  return [...new Set(slides.map(slide => Math.min(slide.offsetLeft - start, max)))];
}
function updateCarousel() {
  const max = track.scrollWidth - track.clientWidth;
  previous.disabled = track.scrollLeft < 3;
  next.disabled = track.scrollLeft > max - 3;
  const index = slides.reduce((nearest, slide, i) => Math.abs(slide.offsetLeft - slides[0].offsetLeft - track.scrollLeft) < Math.abs(slides[nearest].offsetLeft - slides[0].offsetLeft - track.scrollLeft) ? i : nearest, 0);
  count.textContent = `${String(next.disabled ? slides.length : index + 1).padStart(2, '0')} / 05`;
}
function advance(step) {
  const stops = positions();
  const target = step > 0 ? stops.find(position => position > track.scrollLeft + 3) : [...stops].reverse().find(position => position < track.scrollLeft - 3);
  if(target !== undefined) track.scrollTo({left:target, behavior:reducedMotion.matches ? 'instant' : 'smooth'});
}
function scheduleCarousel() {
  clearTimeout(timer);
  if(!playing || !inView || hovered || focused || document.hidden) return;
  timer = setTimeout(() => {
    if(next.disabled) direction = -1;
    if(previous.disabled) direction = 1;
    advance(direction);
    scheduleCarousel();
  }, 5500);
}
function updatePlayback() {
  play.setAttribute('aria-label', playing ? 'Pause automatic scrolling' : 'Start automatic scrolling');
  play.querySelector('span').textContent = playing ? 'Ⅱ' : '▷';
  scheduleCarousel();
}
function pauseForInteraction() { playing = false; updatePlayback(); }
previous.addEventListener('click', () => {pauseForInteraction();advance(-1);});
next.addEventListener('click', () => {pauseForInteraction();advance(1);});
play.addEventListener('click', () => {playing = !playing;updatePlayback();});
track.addEventListener('keydown', event => {
  if(event.key === 'ArrowLeft' || event.key === 'ArrowRight') {event.preventDefault();pauseForInteraction();advance(event.key === 'ArrowRight' ? 1 : -1);}
});
track.addEventListener('pointerdown', pauseForInteraction, {passive:true});
track.addEventListener('wheel', pauseForInteraction, {passive:true});
track.addEventListener('scroll', updateCarousel, {passive:true});
carousel.addEventListener('mouseenter', () => {hovered = true;scheduleCarousel();});
carousel.addEventListener('mouseleave', () => {hovered = false;scheduleCarousel();});
carousel.addEventListener('focusin', () => {focused = true;scheduleCarousel();});
carousel.addEventListener('focusout', event => {if(!carousel.contains(event.relatedTarget)) {focused = false;scheduleCarousel();}});
document.addEventListener('visibilitychange', scheduleCarousel);
window.addEventListener('resize', updateCarousel, {passive:true});
reducedMotion.addEventListener('change', () => {if(reducedMotion.matches) pauseForInteraction();});
if('IntersectionObserver' in window) new IntersectionObserver(entries => {inView = entries[0].isIntersecting;scheduleCarousel();}, {threshold:.2}).observe(carousel);
updateCarousel();
updatePlayback();
