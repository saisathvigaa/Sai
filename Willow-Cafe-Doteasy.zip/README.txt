THE WILLOW CAFE - WEBSITE FILES (for Doteasy hosting)

1. Log in to Doteasy and open cPanel > File Manager.
2. Open the public_html folder. Delete or rename any default index page there.
3. Upload this zip into public_html and choose Extract. index.html must sit
   directly inside public_html (not in a subfolder).
4. Turn on "Show Hidden Files" in File Manager settings to confirm .htaccess is there.
5. Point DNS back to Doteasy: remove the A record 75.2.60.5 and the www CNAME to
   netlify.app, and restore Doteasy's default hosting records.
6. Enable SSL in cPanel (SSL/TLS Status or AutoSSL / Let's Encrypt) for
   thewillowcafe.ca and www.thewillowcafe.ca.

Until SSL is active, .htaccess redirects to https and the site will show a warning.
If that happens, rename .htaccess temporarily, then rename it back once SSL works.
